#!/bin/bash

for ((x = -10;x<=10;x=x+1))
	do
	let r=$x*$x
	echo $r
done
